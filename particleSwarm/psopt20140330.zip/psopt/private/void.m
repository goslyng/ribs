function y = void(varargin)

y = 0 ;