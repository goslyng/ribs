#!/bin/sh

# Copyright 2006 The MathWorks, Inc.

# Stop MATLAB pe - simply clean up $TMPDIR/machines

/bin/rm -f "$TMPDIR/machines"